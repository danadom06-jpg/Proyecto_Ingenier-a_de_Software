<?php
header("Content-Type: application/json; charset=UTF-8");
require_once "../config/db.php";

$metodo = $_SERVER['REQUEST_METHOD'];

switch ($metodo) {
    case 'GET':
        $stmt = $pdo->query("SELECT m.id_miembro, m.nombre, m.email, m.telefono, m.estatus, mem.nombre AS membresia 
                             FROM miembros m 
                             LEFT JOIN membresias mem ON m.id_membresia = mem.id_membresia 
                             ORDER BY m.id_miembro DESC");
        echo json_encode($stmt->fetchAll());
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if (!empty($data['nombre']) && !empty($data['email']) && !empty($data['id_membresia'])) {
            $sql = "INSERT INTO miembros (nombre, email, telefono, id_membresia) VALUES (?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$data['nombre'], $data['email'], $data['telefono'] ?? null, $data['id_membresia']]);
            echo json_encode(["status" => "success", "id" => $pdo->lastInsertId()]);
        } else {
            http_response_code(400);
            echo json_encode(["error" => "Datos incompletos"]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Método no permitido"]);
        break;

        case 'DELETE':
        // Borrar miembro de forma definitiva
        $data = json_decode(file_get_contents("php://input"), true);
        $id_miembro = $data['id_miembro'] ?? $_GET['id_miembro'] ?? null;

        if (!empty($id_miembro)) {
            $stmt = $pdo->prepare("DELETE FROM miembros WHERE id_miembro = ?");
            $stmt->execute([$id_miembro]);
            echo json_encode(["status" => "success", "mensaje" => "Socio eliminado permanentemente"]);
        } else {
            http_response_code(400);
            echo json_encode(["error" => "ID de miembro requerido"]);
        }
        break;
}