.<?php
header("Content-Type: application/json; charset=UTF-8");
require_once __DIR__ . '/../config/db.php';

try {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE usuario = ?");
    $stmt->execute(['gerente']);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(["status" => "error", "mensaje" => "El usuario 'gerente' NO existe en la tabla usuarios"]);
        exit;
    }

    $password_valida = password_verify('gerente123', $user['password']);

    echo json_encode([
        "status" => "ok",
        "conexion_bd" => "Exitosa",
        "usuario_encontrado" => $user['usuario'],
        "rol" => $user['rol'],
        "password_verify" => $password_valida ? "CORRECTO (Coincide)" : "FALLÓ (El hash no coincide con 'gerente123')"
    ]);
} catch (\Exception $e) {
    echo json_encode(["error_critico" => $e->getMessage()]);
}
