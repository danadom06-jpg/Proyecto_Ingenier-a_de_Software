<?php
require_once __DIR__ . '/../config/db.php';

try {
    // Generamos el hash real y seguro para 'gerente123'
    $nuevo_hash = password_hash('gerente123', PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("UPDATE usuarios SET password = ? WHERE usuario = 'gerente'");
    $stmt->execute([$nuevo_hash]);

    echo json_encode([
        "status" => "success",
        "mensaje" => "¡Contraseña actualizada y sincronizada correctamente para el usuario 'gerente'!"
    ]);
} catch (\Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
