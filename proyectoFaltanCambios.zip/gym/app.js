const form = document.getElementById('formmiembro');
const tabla = document.getElementById('tabla-miembros');

// Cargar miembros desde la API
async function cargarMiembros() {
    try {
        const res = await fetch('api/miembros.php');
        const miembros = await res.json();
        
        tabla.innerHTML = miembros.map(m => `
            <tr>
                <td>#${m.id_miembro}</td>
                <td>${m.nombre}</td>
                <td>${m.email}</td>
                <td>${m.telefono || 'N/A'}</td>
                <td>${m.membresia}</td>
                <td><span class="status-badge">${m.estatus}</span></td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error cargando miembros:', error);
    }
}


function buscarGlobal() {
            const query = document.getElementById('input-buscar-global').value.trim();
            
            // Sincronizar con el campo secundario si existe
            const inputSecundario = document.getElementById('input-buscar');
            if (inputSecundario) inputSecundario.value = query;

            fetch(`api/miembros.php?q=${encodeURIComponent(query)}`)
                .then(res => res.json())
                .then(miembros => {
                    // Actualizar tabla principal de miembros
                    const tbody = document.getElementById('tabla-miembros');
                    if (tbody) {
                        tbody.innerHTML = '';
                        if (miembros.length > 0) {
                            const hoy = new Date();
                            hoy.setHours(0, 0, 0, 0);

                            miembros.forEach(m => {
                                let alertaVencimiento = '';
                                if (m.fecha_vencimiento) {
                                    const fechaVenc = new Date(m.fecha_vencimiento + 'T00:00:00');
                                    const diferenciaDias = Math.ceil((fechaVenc - hoy) / (1000 * 60 * 60 * 24));

                                    if (diferenciaDias < 0) {
                                        alertaVencimiento = `<br><span class="badge Baja.Definitiva" style="margin-top:4px;">⚠️ Vencido</span>`;
                                    } else if (diferenciaDias <= 5) {
                                        alertaVencimiento = `<br><span class="badge Baja.Temporal" style="margin-top:4px;">⏳ Vence en ${diferenciaDias} día${diferenciaDias === 1 ? '' : 's'}</span>`;
                                    }
                                }

                                tbody.innerHTML += `
                                    <tr>
                                        <td><strong>${m.nombre}</strong></td>
                                        <td>${m.email}<br><small style="color:var(--text-muted);">${m.telefono || 'Sin teléfono'}</small></td>
                                        <td>${m.membresia} ($${m.precio})</td>
                                        <td>
                                            <span class="badge ${m.estatus.replace(/\s+/g, '.')}">${m.estatus}</span>
                                            ${alertaVencimiento}
                                        </td>
                                        <td>${m.registrado_por || 'Sistema'}</td>
                                        <td>
                                            <div class="actions-cell">
                                                <button class="btn-sm btn-info" onclick="cambiarPlan(${m.id_miembro})">Cambiar Plan</button>
                                                <button class="btn-sm btn-whatsapp" onclick="enviarWhatsApp('${m.telefono || ''}', '${m.nombre}')">💬 WhatsApp</button>
                                                ${m.estatus !== 'Activo' ? `<button class="btn-sm btn-success" onclick="actualizarEstatus(${m.id_miembro}, 'Activo')">Reactivar</button>` : ''}
                                                ${m.estatus !== 'Baja Temporal' ? `<button class="btn-sm btn-warning" onclick="actualizarEstatus(${m.id_miembro}, 'Baja Temporal')">Pausar</button>` : ''}
                                                ${m.estatus !== 'Baja Definitiva' ? `<button class="btn-sm btn-danger" onclick="actualizarEstatus(${m.id_miembro}, 'Baja Definitiva')">Dar Baja</button>` : ''}
                                                <button class="btn-sm" style="background:#059669; color:white;" onclick="renovarMembresia(${m.id_miembro})">Renovar</button>
                                            </div>
                                        </td>
                                    </tr>
                                `;
                            });
                        } else {
                            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: var(--text-muted);">No se encontraron coincidencias</td></tr>`;
                        }
                    }
                });
        }

// Guardar nuevo miembro
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
const payload = {
    nombre: document.getElementById('m-nombre').value.trim(),
    email: document.getElementById('m-email').value.trim(),
    telefono: document.getElementById('m-telefono').value.trim(),
    id_membresia: document.getElementById('m-membresia').value
};

    const res = await fetch('api/miembros.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });

    if (res.ok) {
        form.reset();
        cargarMiembros();
    } else {
        alert('Error al guardar el miembro.');
    }
});

document.addEventListener('DOMContentLoaded', cargarMiembros);